<?php


if (!class_exists("ars_admin")) {
    class ars_admin
    {


        public function __construct()
        {
            add_action("admin_menu", array($this, "add_admin_menu"));
            add_action("admin_menu", array($this, "wpse_register_settings"));

            add_action("rest_api_init", array($this, "train_model_endpoint"));
        }

        public function train_model_endpoint()
        {
            register_rest_route("ars/v1", "train", array(
                "methos" => "post",
                "callback" => array($this, "train_data_call"),
            ));
        }

        // Register and sanitize the settings
        public function wpse_register_settings()
        {
            // Register a setting for each field
            register_setting('ars-options-subsettings-group', 'server_ip');
            register_setting('ars-options-subsettings-group', 'server_port');

            // Add sections and fields to the settings page
            add_settings_section(
                'ars-options-section',  // Section ID
                'Réentraînement du moteur de recommandation',     // Section title
                array($this, 'plugin_settings_callback'),  // Callback function to render the section description
                'ars-options-page'     // Page slug
            );


            // Add sections and fields to the sub settings page
            add_settings_section(
                'ars-sub-options-section', // Section ID
                'Configuration du systeme de recommandation',        // Section title
                array($this, 'wpse_render_sub_section_description'), // Callback function to render the section description
                'ars-sub-options-settings-page'    // Page slug
            );

            add_settings_field(
                'server_ip',             // Field ID
                'Adresse IP :',             // Field title
                array($this, 'wpse_render_field_1'),  // Callback function to render the field
                'ars-sub-options-settings-page',    // Page slug
                'ars-sub-options-section'  // Section ID
            );

            add_settings_field(
                'server_port',
                'Port :',
                array($this, 'wpse_render_field_2'),
                'ars-sub-options-settings-page',
                'ars-sub-options-section'
            );

            // Add more fields and sections as needed
        }

        public function wpse_render_sub_section_description()
        { ?>
            <div class="wrap">
            <p>Bienvenue sur la page de configuration du système de recommandation. Cette page vous permet de personnaliser la manière dont notre plugin de recommandation interagit avec le système de recommandation en définissant une adresse IP et un port spécifiques.</p>
            <p>L'adresse IP et le port que vous indiquez ici seront utilisés pour établir une connexion avec le système de recommandation, ce qui nous permettra de récupérer du contenu recommandé personnalisé basé sur vos intérêts spécifiques en tant qu'utilisateur du site.</p>
            <p>Pour commencer, veuillez entrer l'adresse IP et le port dans les champs correspondants ci-dessous, puis cliquez sur le bouton "Enregistrer" pour sauvegarder vos modifications. Vous pourrez toujours revenir plus tard et modifier ces informations si nécessaire.</p>
            </div>
            <style>
        .custom-alert-success {
        position: relative;
        padding: 15px;
        margin-bottom: 1rem;
        border: 1px solid transparent;
        border-radius: .25rem;
        color: #0f5132;
        background-color: #d1e7dd;
        border-color: #badbcc;
             }
           </style>
            <div class="custom-alert-success">
            <p>Pour afficher le contenu de manière dynamique, vous n'avez qu'à créer une nouvelle page avec un titre de votre choix. Ensuite, ajoutez un "ShortCode" dans le corps de la page en insérant [recommended-articles]. 
            </br> Ce code affichera automatiquement les articles recommandés sur cette page, permettant une personnalisation et une interaction plus poussées avec vos utilisateurs.</p>
            </div>
          
        <?php }

        public function train_data_call($request)
        {
            // Retrieve request parameters
            $params = $request->get_params();

            $result = array(
                "success" => true,
                "message" => "Model trained successfully"
            );

            sleep(10);

            // Create a response object
            $response = new WP_REST_Response($result);

            // Set the response status code
            $response->set_status(200);

            return $response;
        }



        public function add_admin_menu()
        {
            add_menu_page(
                "ARS Options",
                "ARS Options",
                "manage_options",
                "ars_options",
                array($this, "wpse_render_settings_page")
            );

            add_submenu_page("ars_options", "API Settings", "API Settings", "manage_options", "ars_api_options", array($this, "wpse_render_api_settings_page"));
        }


        public function wpse_render_api_settings_page()
        { ?>
            <div class="wrap">
                <form method="post" action="options.php">
                    <?php
                    settings_fields('ars-options-subsettings-group');
                    do_settings_sections('ars-sub-options-settings-page');
                    submit_button();
                    ?>
                </form>
            </div>

        <?php
        }

        // Render the settings page
        function wpse_render_settings_page()
        {
        ?>
            <div class="wrap">
                <form method="post" action="options.php">
                    <?php
                    settings_fields('ars-options-group');
                    do_settings_sections('ars-options-page');
                    ?>
                </form>
            </div>
        <?php
        }


        // Render the section description
        public function wpse_render_section_description()
        {
            echo '<p>Collez le shortcode [recommended-articles] dans la page ou vous voulez que le contenu s\'affiche .</p>';
        }

        // Render the first field
        function wpse_render_field_1()
        {
            $value = get_option('server_ip', '');
            echo '<input type="text" name="server_ip" value="' . esc_attr($value) . '" />';
        }

        // Render the second field
        function wpse_render_field_2()
        {
            $value = get_option('server_port', '');
            echo '<input type="text" name="server_port" value="' . esc_attr($value) . '" />';
        }


        public function plugin_settings_callback()
        {
        ?>
            <div class="wrap">
                <h4>Cliquez sur "Commencer le réentraînement" pour lancer le réentraînement de moteur de recommandation</h4>
                <p>
                    Attention : En appuyant sur 'Commencer le réentraînement', vous autorisez le système à utiliser les données enregistrées sur ce site pour réentraîner le moteur de recommandation. Cela permettra d'améliorer l'expérience utilisateur en fournissant du contenu personnalisé et pertinent. Toutes les données utilisées seront traitées de manière anonyme et sécurisée. Pour plus d'informations, veuillez consulter notre politique de confidentialité.
                </p>
                <label>
                    <input type="checkbox" id="confirmationCheckbox">J'accepte les conditions et autorise le système à utiliser les données enregistrées sur ce site pour réentraîner le moteur de recommandation.
                </label>
                </br>
                </br>
                <button class="button button-primary" id="trainmodel">Commencer le réentraînement</button>
            </div>
<?php
        }
    }
}
