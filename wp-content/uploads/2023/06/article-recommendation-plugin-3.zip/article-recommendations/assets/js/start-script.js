(function ($) {
  $(document).ready(function () {
    $.ajax({
      type: "post",
      url: ss_object.ajaxurl,
      data: {
        action: "articles_rs_start_script",
        id: ss_object.id,
      },
    });

    $.ajax({
      type: "post",
      url: ss_object.ajaxurl,
      data: {
        action: "articles_rs_test_start_script",
        id: ss_object.id,
      },
    });
  });
})(jQuery);
