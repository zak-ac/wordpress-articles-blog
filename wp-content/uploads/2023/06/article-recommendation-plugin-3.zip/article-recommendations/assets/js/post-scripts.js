(function ($) {
  $(document).ready(function () {
    $.ajax({
      type: "post",
      url: postObj.ajaxurl,
      data: {
        action: "mark_viewed_post",
        user_id: postObj.user_id,
        post_id: postObj.post_id,
      },
    });
  });
})(jQuery);
