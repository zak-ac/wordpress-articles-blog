(function ($) {
  $(document).ready(function () {
    var cookiesPopup = $("#arsCookiesPopupOverlay");
    $("#acceptCookiesButton").on("click", function () {
      cookiesPopup.hide();
      $.ajax({
        type: "POST",
        url: ajax_object.ajax_url,
        data: {
          action: "ars_accept_cookies",
        },
        success: function (response) {
          var res = JSON.parse(response);

          console.log("RESPONSE: ", res);
        },
      });
    });
    $(".cat-container")
      .children()
      .each(function () {
        $(this).click(function () {
          $(this).toggleClass("focused");
        });
      });
    $("#submitCat").click(function () {
      var catsArray = [];
      $(".cat-container").each(function () {
        $(this)
          .children()
          .each(function (index, item) {
            if ($(item).hasClass("focused")) {
              var post_id = $(item).attr("data-postid");
              catsArray.push(post_id);
            }
          });
      });

      if (catsArray.length == 0) {
        var allCatsSTR = "[" + $("#allCat").val() + "]";
        var allCats = JSON.parse(allCatsSTR);

        catsArray = allCats;
      }

      $.ajax({
        url: ajax_object.ajax_url,
        type: "post",
        data: {
          action: "ars_save_categories",
          categories: catsArray,
        },
        success: function (data) {
          console.log("DATA: ", data);
          var data = JSON.parse(data);
        },
      });

      $.ajax({
        url: ajax_object.ajax_url,
        type: "POST",
        data: {
          action: "ars_init_search_query",
          categories: catsArray,
        },
        success: function (data) {
          var res = JSON.parse(data);
          console.log("RESPONSE: ", res);
          $(".articles-container").html(res.content);
        },
      });

      $(".cat-popup-overlay").hide();
    });
  });
})(jQuery);
