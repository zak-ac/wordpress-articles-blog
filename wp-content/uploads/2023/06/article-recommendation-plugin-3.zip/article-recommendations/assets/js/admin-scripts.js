(function ($) {
  $(document).ready(function () {
    var trainButton = $("#trainmodel");

    trainButton.on("click", function (event) {
      event.preventDefault();

      $.ajax({
        type: "get",
        url: urlObj.url,
        data: {
          action: "ajax_train_model",
        },
        beforeSend: function () {
          var content = '<span class="loader"></span>Chargement..';

          trainButton.prop("disabled", true);
          trainButton.html(content);
        },
        success: function (res) {
          trainButton.prop("disabled", false);
          trainButton.html("Commencer le réentraînement");
        },
      });
    });
  });
})(jQuery);
