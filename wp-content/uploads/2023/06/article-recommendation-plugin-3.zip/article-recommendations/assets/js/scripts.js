(function ($) {
  $(document).ready(function () {
    $("#searchSubmit").click(function (e) {
      e.preventDefault();

      var searchValue = $("#zakSearchInput").val();
      var user_id = $("#zakSearchInput").data("user-id");
      var user_ip = $("#zakSearchInput").data("user-ip");

      console.log("HELLO WORLD!!!");

      $.ajax({
        url: obj.ajaxurl,
        type: "POST",
        data: {
          action: "articles_rs_search_query",
          query: searchValue,
          user_id: user_id,
          user_ip: user_ip,
        },
        success: function (data) {
          var res = JSON.parse(data);
          console.log("RESPONSE: ", res);
          $(".articles-container").html(res.content);
        },
      });
    });
  });
})(jQuery);
