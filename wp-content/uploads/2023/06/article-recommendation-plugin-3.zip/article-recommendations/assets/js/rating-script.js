(function ($) {
  $(document).ready(function () {
    var userID = $("#post_rating").data("user-id");
    var postID = $("#post_rating").data("post-id");

    $("#post_rating").barrating({
      theme: "css-stars",
      initialRating: obj.defaultRating,
      onSelect: function (value, text, event) {
        $.ajax({
          type: "post",
          url: obj.ajaxurl,
          data: {
            action: "dfr_rate_post",
            user_id: userID,
            post_id: postID,
            rating: value,
          },
        });
      },
    });
  });
})(jQuery);
