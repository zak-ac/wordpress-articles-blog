<?php


if (!class_exists("DFR_Search_terms")) {
    class DFR_Search_terms
    {

        public $table_name;

        public function __construct()
        {
            $this->get_table_name();
        }

        private function get_table_name()
        {
            global $wpdb;
            $this->table_name = $wpdb->prefix . ARTICLE_RS_SEARCH_TERMS_TABLE;
        }

        public function update_interaction($field, $value, $user_id)
        {
            global $wpdb;

            if (array($value)) {
                $data = array(
                    $field => serialize($value)
                );
            } else {
                $data = array(
                    $field => $value
                );
            }

            $where = array(
                'user_id' => $user_id
            );

            $wpdb->update(
                $this->table_name,
                $data,
                $where
            );
        }

        public function insert_row($user_id)
        {
            global $wpdb;
            $last_inserted_id = false;

            $data = array(
                "user_id" => $user_id,
            );

            $rows_affected = $wpdb->insert($this->table_name, $data);

            if ($rows_affected) {
                $last_inserted_id = $wpdb->insert_id;
                return $last_inserted_id;
            } else {
                return $last_inserted_id;
            }
        }

        public function get_search_terms($user_id)
        {
            global $wpdb;
            $res = array();

            $sql = "SELECT search_terms FROM {$this->table_name} WHERE user_id = $user_id";

            $query = $wpdb->prepare($sql);

            $results = $wpdb->get_var($query);

            if ($results == null) {
                $res = array();
            } else {
                $search_results = unserialize($results);

                $res = $search_results;
            }

            return $res;
        }

        public function save_search_term($term, $user_id = false, $user_ip = false)
        {
            global $wpdb;

            // Getting the previous searched terms
            $previous_search_terms = $this->get_search_terms($user_id);

            $new_search_term = array(
                array(
                    "search_term" => $term,
                    "search_date" => current_time('mysql')
                )
            );

            $all_terms = array_merge($previous_search_terms, $new_search_term);

            $data = array(
                "search_terms" => serialize($all_terms)
            );

            $where = array(
                'user_id' => $user_id
            );

            $success = $wpdb->update(
                $this->table_name,
                $data,
                $where
            );

            if (!$success) {
                $res = array(
                    "status" => "error",
                    "message" => "Failed adding the search term"
                );
            } else {
                $res = array(
                    "status" => "success",
                    "message" => "Added search term successfully"
                );
            }

            return $res;
        }


        public function check_user_exists($user_id)
        {
            global $wpdb;

            $query = $wpdb->prepare(
                "SELECT COUNT(*) FROM {$this->table_name} WHERE user_id = %d",
                $user_id
            );

            $result = $wpdb->get_var($query);

            return $result > 0;
        }

        public function add_last_visited($user_id)
        {
            global $wpdb;

            $current_time = current_time('mysql');

            $data = array(
                'last_visited' => $current_time
            );

            $where = array(
                'user_id' => $user_id
            );

            $wpdb->update($this->table_name, $data, $where);
        }

        public function check_table($table_name)
        {
            global $wpdb;

            $table_name = $wpdb->prefix . $table_name;

            $table_exists = $wpdb->query("SHOW TABLES LIKE '$table_name'");

            return $table_exists;
        }

        public function create_table($user_id)
        {
            try {
                global $wpdb;

                $sql = "CREATE TABLE $this->table_name (
                    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
                    user_id BIGINT UNSIGNED NOT NULL,
                    search_terms LONGTEXT DEFAULT NULL,
                    PRIMARY KEY (id),
                    FOREIGN KEY (user_id) REFERENCES {$wpdb->prefix}users(ID) ON DELETE CASCADE
                ) ENGINE=InnoDB;";



                require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
                dbDelta($sql);

                $wpdb->replace($this->table_name, array(
                    'user_id' => $user_id
                ), array(
                    '%d'
                ));
            } catch (Exception $e) {
                return $e;
            }
        }
    }
}
