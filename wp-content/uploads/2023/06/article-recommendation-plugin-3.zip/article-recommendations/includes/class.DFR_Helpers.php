<?php

if (!class_exists('DFR_Helpers')) {
    class DFR_Helpers
    {

        public $server_ip;
        public $server_port;

        public function __construct()
        {
            $this->server_ip = get_option("server_ip");
            $this->server_port = get_option("server_port");
        }

        public function get_categories_by_ids($categories_array)
        {
            $category_slugs = [];

            foreach ($categories_array as $category_id) {
                $category = get_category($category_id);
                $category_slug = $category->slug;

                $category_slugs[] = $category->slug;
            }

            return $category_slug;
        }

        public function get_articles_from_rs()
        {
            $user_id = get_current_user_id();
            $user_interactions = new DFR_User_interactions();

            $categories_ids = $user_interactions->get_categories($user_id);

            $categories_slugs = $this->get_categories_by_ids($categories_ids);

            $url = $this->server_ip . ":" . $this->server_port . "/recommend_articles";

            // Checking if the user is newly registered
            $previous_user_interactions = $user_interactions->get_all_interactions();

            if (empty($previous_user_interactions)) {
                if ($categories_slugs) {
                    $data = array(
                        "user_id" => "U" . $user_id,
                        "num_recs" => 24,
                        "list_cats" => [$categories_slugs],
                        "rec_type" => "content"
                    );
                } else {
                    $data = array(
                        "user_id" => "U" . $user_id,
                        "num_recs" => 24,
                        "list_cats" => [$categories_slugs],
                        "rec_type" => "random"
                    );
                }
            } else {
                $data = array(
                    "user_id" => "U" . $user_id,
                    "num_recs" => 24,
                    "list_cats" => [$categories_slugs],
                    "rec_type" => "collaborative"
                );
            }



            $args = array(
                'body' => $data, // Data to be sent in the request body
                'timeout' => 15, // Timeout value in seconds (adjust as needed)
                'headers' => array(
                    'Content-Type' => 'application/x-www-form-urlencoded' // Adjust content type if needed
                )
            );

            $response = wp_remote_get($url, $args);

            if (is_wp_error($response)) {
                // An error occurred
                $error_message = $response->get_error_message();

                $res = array(
                    "message" => $error_message
                );

                return $res;
            } else {
                echo "<pre>";
                print_r($response);
                echo "</pre>";
                die();
                $response_code = wp_remote_retrieve_response_code($response);
                $response_body = wp_remote_retrieve_body($response);

                return array(
                    "code" => $response_code,
                    "body" => $response_body
                );
            }
        }

        public function parse_user_interactions($user_interactions)
        {
            $user_interactions = new DFR_User_interactions();

            $all_interactions = $user_interactions->get_all_interactions();

            $return_array = array();

            foreach ($all_interactions as $interaction) {
                $interaction_array = array(
                    "user_id" => $interaction["user_id"],
                    "time" => $interaction["viewed_at"],
                    "history" => unserialize($interaction["viewed_articles"]),
                    "impressions" => unserialize($interaction["rating"])
                );

                $return_array[] = $interaction_array;
            }

            return $return_array;
        }

        public function get_all_posts_for_model()
        {
            $posts = get_posts(array(
                'post_type'      => 'post',
                'posts_per_page' => -1,
            ));

            $post_data = array();

            foreach ($posts as $post) {
                $news_id = $post->ID;
                $category = get_the_category($news_id)[0]->slug;
                $sub_category = get_the_category($news_id)[0]->slug;
                $title = get_the_title($news_id);
                $abstract = get_the_excerpt($news_id);

                $post_data[] = array(
                    'news_id'      => $news_id,
                    'category'     => $category,
                    'sub_category' => $sub_category,
                    'title'        => $title,
                    'abstract'     => $abstract,
                );
            }

            return $post_data;
        }

        public function get_user_from_session_id()
        {
            $session_id = $_COOKIE['session_id'];

            $user = $this->check_for_user_session_id($session_id);

            return $user->ID;
        }

        public function check_for_user_session_id($session_id)
        {
            $user_args = array(
                'meta_key' => 'session_id',
                'meta_value' => $session_id,
                'meta_compare' => '='
            );

            $user_query = new WP_User_Query($user_args);

            $users = $user_query->get_results();

            if (count($users) > 0) {
                return $users[0];
            } else {
                return false;
            }
        }


        public function add_categories_from_model($slugs)
        {
            foreach ($slugs as $slug) {
                $category = get_term_by('slug', $slug, 'category');

                if (!$category) {
                    wp_insert_term($slug, 'category', array(
                        'slug' => $slug
                    ));
                } else {
                }
            }
        }

        public function get_categories_from_model()
        {
            $url = $this->server_ip . ":" . $this->server_port . "/list_all_categories";

            $args = array(
                'timeout' => 15, // Timeout value in seconds (adjust as needed)
                'headers' => array(
                    'Content-Type' => 'application/x-www-form-urlencoded' // Adjust content type if needed
                )
            );


            $response = wp_remote_get($url, $args);

            if (is_wp_error($response)) {
                // An error occurred
                $error_message = $response->get_error_message();

                $res = array(
                    "message" => $error_message
                );

                return $res;
            } else {
                // Request was successful
                $response_code = wp_remote_retrieve_response_code($response);
                $response_body = wp_remote_retrieve_body($response);

                return array(
                    "code" => $response_code,
                    "body" => $response_body
                );
            }
        }

        public function retrain_models($endpoint)
        {
            $url = $this->server_ip + ":" + $this->server_port + "/" + $endpoint;

            $args = array(
                'headers' => array(
                    'Content-Type' => 'application/x-www-form-urlencoded'
                )
            );

            $response = wp_remote_post($url, $args);

            if (is_wp_error($response)) {
                // An error occurred
                $error_message = $response->get_error_message();

                $res = array(
                    "message" => $error_message
                );

                return $res;
            } else {
                // Request was successful
                $response_code = wp_remote_retrieve_response_code($response);
                $response_body = wp_remote_retrieve_body($response);

                return array(
                    "code" => $response_code,
                    "body" => $response_body
                );
            }
        }

        public function find_index_of_value_in_array($array, $key, $value)
        {
            foreach ($array as $index => $element) {
                if ($element[$key] && $element[$key] === $value) {
                    return array(
                        "exists" => true,
                        "index" => $index
                    );
                }
            }
            return array(
                "exists" => false
            );
        }
    }
}
