<?php


if (!class_exists("DFR_User_interactions")) {
    class DFR_User_interactions
    {

        public $table_name;

        public function __construct()
        {
            $this->get_table_name();
        }

        private function get_table_name()
        {
            global $wpdb;
            $this->table_name = $wpdb->prefix . ARTICLE_RS_INTERACTION_TABLE;
        }


        public function get_all_interactions()
        {
            global $wpdb;

            $results = $wpdb->get_results("SELECT * FROM $this->table_name", ARRAY_A);

            return $results;
        }

        public function update_interaction($field, $value, $user_id)
        {
            global $wpdb;

            if (array($value)) {
                $data = array(
                    $field => serialize($value)
                );
            } else {
                $data = array(
                    $field => $value
                );
            }

            $where = array(
                'user_id' => $user_id
            );

            $wpdb->update(
                $this->table_name,
                $data,
                $where
            );
        }

        public function get_interaction($field, $user_id)
        {
            global $wpdb;

            $sql = "SELECT {$field} FROM {$this->table_name} WHERE user_id = $user_id";

            $query = $wpdb->prepare($sql, $user_id);


            $result = $wpdb->get_var($query);

            if (is_serialized($result)) {
                $res = unserialize($result);
            } else {
                $res = $result;
            }

            return $res;
        }

        public function get_rating($post_id, $user_id)
        {
            global $wpdb;

            $sql = "SELECT rating FROM {$this->table_name} WHERE user_id = $user_id";

            $query = $wpdb->prepare($sql);

            $result = $wpdb->get_var($query);

            if ($result == null) {
                return 3;
            } else {
                $rating_array = unserialize($result);

                $helpers = new DFR_Helpers();


                $post_rating = $helpers->find_index_of_value_in_array($rating_array, 'post_id', $post_id);

                if ($post_rating['exists']) {

                    $rating = $rating_array[$post_rating['index']]['rating'];

                    return $rating;
                }
            }
        }

        public function insert_row($user_id)
        {
            global $wpdb;
            $last_inserted_id = false;

            $table_data = array(
                "user_id" => $user_id,
                "viewed_articles" => [],
                "rating" => [],
                "selected_categories" => [],
            );

            $rows_affected = $wpdb->insert($this->table_name, $table_data);


            if ($rows_affected) {
                $last_inserted_id = $wpdb->insert_id;
                return $last_inserted_id;
            } else {
                return $last_inserted_id;
            }
        }

        public function get_categories($user_id, $jsonify = false)
        {
            global $wpdb;

            $sql = "SELECT selected_categories FROM {$this->table_name} WHERE user_id = $user_id";

            $query = $wpdb->prepare($sql);

            $result = $wpdb->get_var($query);

            if ($result == null) {
                $res = array();
            } else {
                $categories_results = unserialize($result);

                $res = $categories_results;

                if ($jsonify) {
                    $res = json_encode($res);
                    return $res;
                } else {
                    return $res;
                }
            }
        }

        public function get_search_terms($user_id)
        {
            global $wpdb;
            $res = array();

            $sql = "SELECT search_terms FROM {$this->table_name} WHERE user_id = $user_id";

            $query = $wpdb->prepare($sql);

            $results = $wpdb->get_var($query);

            if ($results == null) {
                $res = array();
            } else {
                $search_results = unserialize($results);

                $res = $search_results;
            }

            return $res;
        }

        public function save_search_term($term, $user_id = false, $user_ip = false)
        {
            global $wpdb;

            // Getting the previous searched terms
            $previous_search_terms = $this->get_search_terms($user_id);

            $new_search_term = array($term);

            $all_terms = array_merge($previous_search_terms, $new_search_term);

            $data = array(
                "search_terms" => $all_terms
            );

            $where = array(
                'user_id' => $user_id
            );

            $success = $wpdb->update(
                $this->table_name,
                $data,
                $where
            );

            if (!$success) {
                $res = array(
                    "status" => "error",
                    "message" => "Failed adding the search term"
                );
            } else {
                $res = array(
                    "status" => "success",
                    "message" => "Added search term successfully"
                );
            }

            return $res;
        }


        public function save_categories($categories, $user_id)
        {
            if (!array($categories)) {
                $res = array(
                    "message" => "The categories is not an array"
                );

                echo json_encode($res);
                die();
            }
            global $wpdb;


            $data = array(
                "selected_categories" => serialize($categories)
            );

            $where = array(
                "user_id" => $user_id
            );

            $wpdb->update(
                $this->table_name,
                $data,
                $where
            );
        }

        public function check_user_exists($user_id)
        {
            global $wpdb;

            $query = $wpdb->prepare(
                "SELECT COUNT(*) FROM {$this->table_name} WHERE user_id = %d",
                $user_id
            );

            $result = $wpdb->get_var($query);


            return $result > 0;
        }

        public function add_last_visited($user_id)
        {
            global $wpdb;

            $current_time = current_time('mysql');

            $data = array(
                'last_visited' => $current_time
            );

            $where = array(
                'user_id' => $user_id
            );

            $wpdb->update($this->table_name, $data, $where);
        }

        public function check_table($table_name)
        {
            global $wpdb;

            $table_name = $wpdb->prefix . $table_name;

            $table_exists = $wpdb->query("SHOW TABLES LIKE '$table_name'");

            return $table_exists;
        }

        public function check_if_table_exists()
        {
            global $wpdb;

            $sql = "SELECT SCHEMA_NAME FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME = %s";
            $query = $wpdb->prepare($sql, $this->table_name);

            $results = $wpdb->get_results($query);

            if (count($results)) {
                return true;
            } else {
                return false;
            }
        }

        public function create_table()
        {

            try {
                global $wpdb;

                $sql = "CREATE TABLE $this->table_name (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id BIGINT UNSIGNED NOT NULL,
  viewed_articles LONGTEXT DEFAULT NULL,
  rating LONGTEXT DEFAULT NULL,
  selected_categories LONGTEXT DEFAULT NULL,
  viewed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  FOREIGN KEY (user_id) REFERENCES {$wpdb->prefix}users(ID) ON DELETE CASCADE
) ENGINE=InnoDB;";



                require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
                dbDelta($sql);
            } catch (Exception $e) {
                return $e;
            }
        }
    }
}
