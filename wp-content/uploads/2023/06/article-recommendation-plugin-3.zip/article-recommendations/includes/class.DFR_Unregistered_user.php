<?php


if (!class_exists("DFR_Unregistered_user")) {

    class DFR_Unregistered_user
    {
        public $table_name;
        public $user_ip;

        public function __construct()
        {

            global $wpdb;
            $this->table_name = $wpdb->prefix . ARTICLE_RS_UNREGISTERED_USER;
        }

        public function set_ip()
        {
            $unregistered_user_ip = $_SERVER["REMOTE_ADDR"];
            $this->user_ip = $unregistered_user_ip();
        }

        public function insert_row($user_interaction_id, $search_term_id)
        {
            global $wpdb;
            $last_inserted_id = false;

            $data = array(
                "user_interaction_id" => $user_interaction_id,
                "search_terms_id" => $search_term_id,
                "user_ip"          => $this->user_ip,
            );

            $rows_affected = $wpdb->insert($this->table_name, $data);

            if ($rows_affected) {
                $last_inserted_id = $wpdb->insert_id;
                return $last_inserted_id;
            } else {
                return $last_inserted_id;
            }
        }

        public function check_if_table_exists()
        {
            global $wpdb;

            $table_name = $wpdb->prefix . $this->table_name;

            $table_exists = $wpdb->get_var("SHOW TABLES LIKE '$table_name'") === $table_name;

            if ($table_exists) {
                return true;
            } else {
                return false;
            }
        }

        public function create_table()
        {
            global $wpdb;

            try {
                $sql = "CREATE TABLE $this->table_name (
                    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
                    user_id BIGINT UNSIGNED NOT NULL,
                    user_interaction_id BIGINT UNSIGNED NOT NULL,
                    search_terms_id BIGINT UNSIGNED NOT NULL,
                    user_ip LONGTEXT DEFAULT NULL,
                    PRIMARY KEY (id),
                    FOREIGN KEY (user_id) REFERENCES {$wpdb->prefix}users(ID) ON DELETE CASCADE
                ) ENGINE=InnoDB;";


                // $sql = "CREATE TABLE $this->table_name (
                //     id INT UNSIGNED NOT NULL AUTO_INCREMENT,
                //     user_id BIGINT UNSIGNED NOT NULL,
                //     search_terms LONGTEXT DEFAULT NULL,
                //     PRIMARY KEY (id),
                //     FOREIGN KEY (user_id) REFERENCES {$wpdb->prefix}users(ID) ON DELETE CASCADE
                // ) ENGINE=InnoDB;";


                require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
                dbDelta($sql);
            } catch (Exception $e) {
                return $e;
            }
        }
    }
}
