# ars-wp-plugin
Une méthode de création de contenu dynamique sur base d'une segmentation d'utilisateur créée à partir de données récupérées automatiquement.  * Version: 1.0
# article-recommendations
