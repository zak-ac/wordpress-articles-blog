<?php

if (!class_exists("Articles_rs_ajax")) {
    class Articles_rs_ajax
    {


        public function __construct()
        {
            add_action('wp_ajax_articles_rs_search_query', array($this, 'articles_rs_search_query'));
            add_action('wp_ajax_nopriv_articles_rs_search_query', array($this, 'articles_rs_search_query'));

            // Save categories in cookies
            add_action('wp_ajax_ars_save_categories', array($this, 'ars_ajax_save_categories'));
            add_action('wp_ajax_nopriv_ars_save_categories', array($this, 'ars_ajax_save_categories'));

            // Start script 
            add_action("wp_ajax_articles_rs_start_script", array($this, "articles_rs_start_script"));
            add_action("wp_ajax_nopriv_articles_rs_start_script", array($this, "articles_rs_start_script"));

            // TODO: REMOVE THIS HOOK
            add_action("wp_ajax_articles_rs_test_start_script", array($this, "test_start_script"));
            add_action("wp_ajax_nopriv_articles_rs_test_start_script", array($this, "test_start_script"));

            // Add Views
            add_action("wp_ajax_mark_viewed_post", array($this, "mark_viewed_posts"));
            add_action("wp_ajax_nopriv_mark_viewed_post", array($this, "mark_viewed_posts"));

            // Rate post
            add_action("wp_ajax_dfr_rate_post", array($this, "rate_post"));
            add_action("wp_ajax_nopriv_dfr_rate_post", array($this, "rate_post"));

            // Trigger first search after category selection
            add_action('wp_ajax_ars_init_search_query', array($this, 'ars_init_search_query'));
            add_action('wp_ajax_nopriv_ars_init_search_query', array($this, 'ars_init_search_query'));

            // Accept cookies
            add_action('wp_ajax_ars_accept_cookies', array($this, 'ars_accept_cookies'));
            add_action('wp_ajax_nopriv_ars_accept_cookies', array($this, 'ars_accept_cookies'));

            add_action('wp_ajax_ajax_train_model', array($this, 'ajax_train_model'));
            add_action('rest_api_init', array($this, "initial_database_requests"));
        }


        public function ars_accept_cookies()
        {
            setcookie('accept_terms', "yes", time() + (10 * 365 * 24 * 60 * 60), '/', $_SERVER['HTTP_HOST']);

            $res = array(
                "message" => "Cookies Added"
            );

            echo json_encode($res);
            die();
        }

        public function initial_database_requests()
        {
            register_rest_route(
                "ars_api/v1",
                "get_categories",
                array(
                    "methods" => "GET",
                    "callback" => array($this, "ars_endpoint_get_categories")
                )
            );

            register_rest_route(
                "ars_api/v1",
                "get_posts",
                array(
                    "methods" => "GET",
                    "callback" => array($this, "ars_endpoint_get_posts")
                )
            );

            register_rest_route(
                "ars_api/v1",
                "get_user_interactions",
                array(
                    "methods" => "GET",
                    "callback" => array($this, "ars_endpoint_get_user_interactions")
                )
            );
        }

        public function ars_endpoint_get_user_interactions()
        {
            $helpers = new DFR_Helpers();
            $user_interaction_class = new DFR_User_interactions();

            $user_interactions_array = $user_interaction_class->get_all_interactions();
            $user_interactions = $helpers->parse_user_interactions($user_interactions_array);

            return $user_interactions;
        }

        public function ars_endpoint_get_posts()
        {
            $helpers = new DFR_Helpers();

            $articles = $helpers->get_all_posts_for_model();

            return rest_ensure_response($articles);
        }

        public function ars_endpoint_get_categories()
        {
            // Query all categories
            $categories = get_categories();

            // Prepare the response data
            $category_data = array();
            foreach ($categories as $category) {
                $category_data[] = array(
                    'id'   => $category->term_id,
                    'name' => $category->name,
                    'slug' => $category->slug,
                );
            }

            // Return the response
            return rest_ensure_response($category_data);
        }

        public function ajax_train_model()
        {
            $helpers = new DFR_Helpers();
            $response = $helpers->retrain_models("recommendation_retrain");
        }

        public function ars_init_search_query()
        {
            $helpers = new DFR_Helpers();

            $cat_array = $_POST['categories'];

            $relation = [];

            foreach ($cat_array as $key => $cat) {
                $relation[] = array(
                    'taxonomy' => 'category',
                    'field' => 'term_id',
                    'terms' => $cat,
                );
            }

            $articles_ids = $helpers->get_articles_from_rs();

            if (is_object($articles_ids)) {
                $articles_ids_str = implode(",", $articles_ids);
                $the_query = new WP_Query(array(
                    'post_type' => 'post',
                    's' => '',
                    'posts_per_page' => -1,
                    'post_status' => 'publish',
                    'post__in' => $articles_ids_str,
                ));
            } else {
                $the_query = new WP_Query(array(
                    'post_type' => 'post',
                    's' => '',
                    'posts_per_page' => -1,
                    'post_status' => 'publish',
                    'category__in' => $cat_array,
                ));
            }




            $content = '';

            if ($the_query->have_posts()) :

                $content .= "<div class='posts-container'>";
                while ($the_query->have_posts()) : $the_query->the_post();
                    $content .= "<div class='post-item'>";
                    $content .= "<a href='" . get_the_permalink() . "'>";
                    $content .= get_the_title();
                    $content .= "</a>";
                    $content .= "<div>";
                    $content .= "<p>" . get_the_excerpt() . "</p>";
                    $content .= "</div>";
                    $content .= "<div>";
                    $content .= "<p>" . get_the_date() . "</p>";
                    $content .= "</div>";
                    $content .= "<div>";
                    $content .= "<p>" . get_the_category_list(', ') . "</p>";
                    $content .= "</div>";
                    $content .= "</div>";
                endwhile;
                $content .= "</div>";
                wp_reset_postdata();
            endif;

            $response = array(
                'status' => 'success',
                'content' => $content
            );

            echo json_encode($response);
            die();
        }

        public function rate_post()
        {
            $user_id = get_current_user_id();
            $post_id = $_POST['post_id'];
            $rating = $_POST['rating'];


            $user_interactions = new DFR_User_interactions();

            if ($rating && $post_id && $user_id) {
                $ratings = $user_interactions->get_interaction('rating', $user_id);

                if ($ratings == null) {
                    $ratings = array();

                    $rating_array = array(
                        'post_id' => intval($post_id),
                        'rating' => $rating
                    );

                    array_push($ratings, $rating_array);

                    $user_interactions->update_interaction('rating', $ratings, $user_id);
                } else {
                    $helpers = new DFR_Helpers();
                    $already_rated = $helpers->find_index_of_value_in_array($ratings, 'post_id', intval($post_id));

                    if ($already_rated['exists']) {
                        $ratings[$already_rated['index']]['rating'] = $rating;
                    } else {
                        $rating_array = array(
                            'post_id' => intval($post_id),
                            'rating' => $rating
                        );
                        array_push($ratings, $rating_array);
                    }
                }
                $user_interactions->update_interaction('rating', $ratings, $user_id);
            }

            $res = array(
                "message" => "Rating updated successfully"
            );
            echo json_encode($res);
            die();
        }

        public function mark_viewed_posts()
        {
            $user_id = $_POST['user_id'];
            $post_id = $_POST['post_id'];

            $user_id = get_current_user_id();

            $user_interactions = new DFR_User_interactions();

            $selected_categories = $user_interactions->get_interaction('viewed_articles', $user_id);


            if ($selected_categories == null) {
                $selected_categories = array();
                $viewed_array = array(
                    'post_id' => $post_id,
                    'visits' => 1
                );
                array_push($selected_categories, $viewed_array);
                $user_interactions->update_interaction('viewed_articles', $selected_categories, $user_id);
            } else {
                $helpers = new DFR_Helpers();
                $already_visited = $helpers->find_index_of_value_in_array($selected_categories, 'post_id', $post_id);

                if ($already_visited['exists']) {
                    $selected_categories[$already_visited['index']]['visits'] += 1;
                } else {
                    $viewed_array = array(
                        'post_id' => $post_id,
                        'visits' => 1
                    );
                    array_push($selected_categories, $viewed_array);
                }


                $user_interactions->update_interaction('viewed_articles', $selected_categories, $user_id);
            }

            $res = array(
                "message" => "Views updated successfully"
            );
            echo json_encode($res);
            die();
        }


        public function ars_ajax_save_categories()
        {
            $categories = $_POST['categories'];
            $user_interactions = new DFR_User_interactions();
            $helpers = new DFR_Helpers();

            $user_id = get_current_user_id();

            $user_id = $helpers->get_user_from_session_id();

            try {
                $categories_str = implode(',', $categories);
                setcookie('articles_rs_categories_post', $categories_str, time() + (10 * 365 * 24 * 60 * 60), '/', $_SERVER['HTTP_HOST']);
                setcookie('first_visit', 'yes', time() + (10 * 365 * 24 * 60 * 60), '/', $_SERVER['HTTP_HOST']);


                $user_exists = $user_interactions->check_user_exists($user_id);

                if (!$user_exists) {
                    $user_interactions->insert_row($user_id);
                }

                $user_interactions->save_categories($categories, $user_id);

                $response = array(
                    "status" => "success",
                    "message" => "Categories saved successfully",
                    "home_url" => site_url(),
                );

                echo json_encode($response);
                die();
            } catch (Exception $e) {
                $response = array(
                    "status" => "error",
                    'message' => $e->getMessage(),
                    "home_url" => site_url()
                );

                echo json_encode($response);
                die();
            }
        }

        public function articles_rs_start_script()
        {
            $user_id = get_current_user_id();

            try {
                $user_interactions = new DFR_User_interactions();
                $search_terms = new DFR_Search_terms();
                $u_users = new DFR_Unregistered_user();
                $helpers = new DFR_Helpers();

                $messages = array();

                $u_users->create_table();
                if (is_user_logged_in()) {
                    $check_user_exists = $user_interactions->check_user_exists($user_id);
                    $check_search_term_user_exists = $search_terms->check_user_exists($user_id);

                    $user_interactions_table_exists = $user_interactions->check_if_table_exists();

                    if (!$user_interactions_table_exists) {
                        $user_interactions->create_table();
                    }

                    if (!$check_user_exists) {
                        $user_interactions->insert_row($user_id);
                        $messages[] = "Table created successfully";
                    } else {
                        $user_interactions->add_last_visited($user_id);
                        $messages[] = "Table created successfully";
                    }

                    if (!$check_search_term_user_exists) {
                        $search_terms->create_table($user_id);
                        $messages[] = "Search table created successfully";
                    }
                } else {

                    $session_id = $_COOKIE['session_id'];
                    $unlogged_user = $helpers->check_for_user_session_id($session_id);

                    if ($unlogged_user == false) {
                        $user_login = 'newuser' . uniqid();
                        $user_email = 'new_user_' . uniqid() . '@mail.com';
                        $user_password = uniqid();
                        $new_user_id = wp_create_user($user_login, $user_password, $user_email);
                        $check_user_exists = $user_interactions->check_user_exists($new_user_id);
                        $check_search_term_user_exists = $search_terms->check_user_exists($new_user_id);
                        $user_interactions_table_exists = $user_interactions->check_if_table_exists();


                        if (!$user_interactions_table_exists) {
                            $user_interactions->create_table();
                        }

                        if (!$check_user_exists) {
                            $user_interactions->insert_row($new_user_id);
                            $messages[] = "Table created successfully";
                        } else {
                            $user_interactions->add_last_visited($new_user_id);
                            $messages[] = "Table already created";
                        }


                        if (!is_wp_error($new_user_id)) {
                            $session_id = $session_id;

                            add_user_meta($new_user_id, 'session_id', $session_id);

                            $messages[] = 'New user created successfully with ID: ' . $new_user_id;
                        }
                    } else {
                        $unlogged_user_id = $unlogged_user->ID;

                        wp_set_auth_cookie($unlogged_user_id, true);
                    }

                    $messages[] = "The user needs to be logged in to create a table";
                }

                $res = array(
                    "messages" => $messages
                );

                echo json_encode($res);
                die();
            } catch (Exception $error) {
                echo $error;
                die();
            }
        }

        public function articles_rs_search_query()
        {
            $cat = $_COOKIE['articles_rs_categories_post'];
            $cat_array = explode(',', $cat);
            $srch_terms = new DFR_Search_terms();
            $search_term = $_POST['query'];
            $user_id = $_POST['user_id'];
            $user_ip = $_POST['user_ip'];

            $all_search_terms = $srch_terms->get_search_terms($user_id);
            $save_search = $srch_terms->save_search_term($search_term, $user_id, $user_ip);
            $relation = [];

            foreach ($cat_array as $key => $cat) {
                $relation[] = array(
                    'taxonomy' => 'category',
                    'field' => 'term_id',
                    'terms' => $cat,
                );
            }

            $the_query = new WP_Query(array(
                'post_type' => 'post',
                's' => $_POST['query'],
                'posts_per_page' => -1,
                'post_status' => 'publish',
                'category__in' => $cat_array,
            ));

            $content = '';

            if ($the_query->have_posts()) :

                $content .= "<div class='posts-container'>";
                while ($the_query->have_posts()) : $the_query->the_post();
                    $content .= "<div class='post-item'>";
                    $content .= "<a href='" . get_the_permalink() . "'>";
                    $content .= get_the_title();
                    $content .= "</a>";
                    $content .= "<div>";
                    $content .= "<p>" . get_the_excerpt() . "</p>";
                    $content .= "</div>";
                    $content .= "<div>";
                    $content .= "<p>" . get_the_date() . "</p>";
                    $content .= "</div>";
                    $content .= "<div>";
                    $content .= "<p>" . get_the_category_list(', ') . "</p>";
                    $content .= "</div>";
                    $content .= "</div>";
                endwhile;
                $content .= "</div>";
                wp_reset_postdata();
            endif;

            $response = array(
                'status' => 'success',
                'content' => $content,
                'save_term' => $save_search
            );

            echo json_encode($response);
            die();
        }
    }
}
