<?php

if (!class_exists('Articles_Rs_Search')) {
    class Articles_Rs_Search
    {

        public function __construct()
        {
            add_shortcode('recommended-articles', array($this, 'add_shortcode'));
        }

        public function add_shortcode($atts = array(), $content = null, $tag = '')
        {
            $atts = array_change_key_case((array) $atts, CASE_LOWER);

            extract(shortcode_atts(
                array(
                    'id' => '',
                    'orderby' => 'date'
                ),
                $atts,
                $tag
            ));

            if (!empty($id)) {
                $id = array_map('absint', explode(',', $id));
            }

            ob_start();

            wp_enqueue_style('articles-rs-search-style');
            wp_enqueue_script('articles-rs-search-scripts');
            require(ARTICLES_RS_PATH . 'views/popup.php');
            require(ARTICLES_RS_PATH . 'views/searchbar.php');
            require(ARTICLES_RS_PATH . 'views/cookies.php');

            return ob_get_clean();
        }
    }
}
