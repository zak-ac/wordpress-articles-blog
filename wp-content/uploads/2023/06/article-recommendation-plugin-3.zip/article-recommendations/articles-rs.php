<?php

/**
 * Plugin Name: Article RS Plugin
 * Plugin URI: https://zak2tech.com/
 * Description: Une méthode de création de contenu dynamique sur base d'une segmentation d'utilisateur créée à partir de données récupérées automatiquement dans un environnement WordPress
 * Version: 2.0
 * Requires at least: 5.6
 * Author: Zakaria ACHI
 * Author URI: https://zak2tech.com/
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: articles-rs
 * Domain Path: /languages
 */

/*
Articles RS Plugin is free plugin: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
any later version.
articles-rs is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with MV Slider. If not, see https://www.gnu.org/licenses/gpl-2.0.html.
*/

if (!defined("ABSPATH")) {
    die();
    exit;
}

if (!class_exists('Articles_rs')) {
    class Articles_rs
    {

        public function __construct()
        {
            $this->define_constants();

            require(ARTICLES_RS_PATH . 'shortcodes/class.ars-search.php');
            $articles_rs_search = new Articles_Rs_Search();

            require(ARTICLES_RS_PATH . 'ajax/class.ars-ajax.php');
            $articles_rs_ajax = new Articles_rs_ajax();

            // Loading admin menu page
            require_once(ARTICLES_RS_PATH . 'admin/class.ars.admin.php');
            $articles_rs_admin = new ars_admin();


            require(ARTICLES_RS_PATH . 'includes/class.DFR_User_interactions.php');

            require(ARTICLES_RS_PATH . 'includes/class.DFR_Search_terms.php');

            require(ARTICLES_RS_PATH . 'includes/class.DFR_Helpers.php');

            require_once(ARTICLES_RS_PATH . 'includes/class.DFR_Unregistered_user.php');


            // INIT FUNCTION
            add_action("init", array($this, "initialize_scripts"));

            add_action('wp_enqueue_scripts', array($this, 'scripts_enqueuer'));
            add_action('wp_enqueue_scripts', array($this, 'start_script_enqueuer'));

            // Article scripts 
            add_action('wp_enqueue_scripts', array($this, 'post_scripts_enqueuer'));
            add_action("wp_enqueue_scripts", array($this, 'rate_scripts_enqueuer'));

            // Articles RS Admin enqueuer
            add_action("admin_enqueue_scripts", array($this, "admin_scripts_enqueuer"));

            // Placing the stars section html
            add_action('get_template_part_template-parts/entry-author-bio', array($this, 'add_rating_stars'));

            add_filter('show_admin_bar', array($this, "hide_admin_bar"));
        }

        public function hide_admin_bar($user)
        {
            return current_user_can('administrator') ? $user : false;
        }

        public function ars_create_table()
        {
            $user_id = get_current_user_id();
            $user_interactions = new DFR_User_interactions();
            $search_terms = new DFR_Search_terms();
            $u_users = new DFR_Unregistered_user();

            if (!is_user_logged_in()) {
                $table_exists = $u_users->check_if_table_exists();

                if (!$table_exists) {
                    $u_users->create_table();
                }

                $user_interaction_id = $user_interactions->insert_row($user_id);
                $search_terms_id = $search_terms->insert_row($user_id);


                $u_users->insert_row($user_interaction_id, $search_terms_id);
            }

            $unregistered_users = new DFR_Unregistered_user();
            $table_exists = $unregistered_users->check_if_table_exists();

            if (!$table_exists) {
                $result = $unregistered_users->create_table();
            }
        }

        public function admin_scripts_enqueuer()
        {
            $screen = get_current_screen();

            if ($screen->base == "toplevel_page_ars_options") {
                wp_enqueue_script("ars-admin", ARTICLES_RS_URL . "/assets/js/admin-scripts.js", array("jquery"), false, false);
                wp_localize_script("ars-admin", "urlObj", array(
                    "url" => get_site_url() . "/wp-json/ars/v1/train"
                ));
                wp_enqueue_style("ars-admin-styles", ARTICLES_RS_URL . "/assets/css/admin-css.css", array(), false, false);
            }
        }

        public function initialize_scripts()
        {
            if (!isset($_COOKIE['session_id'])) {
                $random_number = uniqid();
                setcookie('session_id', $random_number, time() + (10 * 365 * 24 * 60 * 60));
            }

            if (is_user_logged_in()) {
                $categories = array();
                $user_interactions = new DFR_User_interactions();
                $user_id = get_current_user_id();
                $categories = $user_interactions->get_categories($user_id);

                if (!empty($categories)) {
                    $categories_str = implode(",", $categories);
                    setcookie('articles_rs_categories_post', $categories_str, time() + (10 * 365 * 24 * 60 * 60), '/', $_SERVER['HTTP_HOST']);
                    setcookie('first_visit', 'yes', time() + (10 * 365 * 24 * 60 * 60), '/', $_SERVER['HTTP_HOST']);
                }
            }
        }

        public function add_rating_stars()
        {
            $user_id = "";
            if (is_user_logged_in()) {
                $user_id = get_current_user_id();
            }
            $content = "";

            $content .= "<div style='display: flex; flex-direction: column;'>";
            $content .= "<h4 style='margin-bottom: 8px;'>Rate this article</h4>";
            $content .= "<div style='width: 100%; display: flex; justify-content: center; align-items: center'>";
            $content .= "<select name='rating' id='post_rating' data-post-id='" . get_the_id() . "' data-user-id='" . $user_id . "'>";
            $content .= "<option value='1'>1</option>";
            $content .= "<option value='2'>2</option>";
            $content .= "<option value='3'>3</option>";
            $content .= "<option value='4'>4</option>";
            $content .= "<option value='5'>5</option>";
            $content .= "</select>";
            $content .= "</div>";
            $content .= "</div>";

            echo $content;
        }

        public function post_scripts_enqueuer()
        {
            if (is_single()) {
                $user_id = "";
                if (is_user_logged_in()) {
                    $user_id = get_current_user_id();
                }
                wp_enqueue_script('post_scripts', ARTICLES_RS_URL . 'assets/js/post-scripts.js', array('jquery'), false, false);

                wp_localize_script("post_scripts", "postObj", array(
                    'ajaxurl' => admin_url('admin-ajax.php'),
                    'user_id' => $user_id,
                    'post_id' => get_the_ID(),
                ));
            }
        }

        public function rate_scripts_enqueuer()
        {
            if (is_single()) {
                $user_id = "";
                if (is_user_logged_in()) {
                    $user_id = get_current_user_id();
                }

                $user_interactions = new DFR_User_interactions();

                $rating = $user_interactions->get_rating(get_the_ID(), $user_id);

                wp_enqueue_script('barrating-script', ARTICLES_RS_URL . 'assets/js/jquery.barrating.js', array('jquery'), false, false);
                wp_enqueue_script('stars_init', ARTICLES_RS_URL . 'assets/js/rating-script.js', array('jquery'), false, false);
                wp_enqueue_style('stars_css', ARTICLES_RS_URL . 'assets/css/stars-css.css');

                wp_localize_script('stars_init', 'obj', array(
                    'ajaxurl' => admin_url("admin-ajax.php"),
                    'defaultRating' => $rating
                ));
            }
        }

        public function scripts_enqueuer()
        {
            wp_enqueue_style("globa-rs-styles", ARTICLES_RS_URL . 'assets/css/custom-styles.css');
            wp_enqueue_script("global-rs-scripts", ARTICLES_RS_URL . 'assets/js/custom-scripts.js', array('jquery'), false, false);
            wp_register_style('articles-rs-search-style', ARTICLES_RS_URL . 'assets/css/search-style.css');
            wp_register_script('articles-rs-search-scripts', ARTICLES_RS_URL . 'assets/js/scripts.js', array('jquery'), '1.0', true);
            wp_localize_script('articles-rs-search-scripts', 'obj', array(
                'ajaxurl' => admin_url('admin-ajax.php'),
            ));

            wp_localize_script("global-rs-scripts", "ajax_object", array(
                'ajax_url' => admin_url('admin-ajax.php'),
            ));
        }

        public function start_script_enqueuer()
        {
            $id = uniqid();
            if (is_user_logged_in()) {
                $id = get_current_user_id();
            }

            wp_enqueue_script('start_script', ARTICLES_RS_URL . 'assets/js/start-script.js', array('jquery'));
            wp_localize_script('start_script', "ss_object", array(
                'ajaxurl' => admin_url('admin-ajax.php'),
                "id" => $id
            ));
        }

        public function define_constants()
        {
            define('ARTICLES_RS_FILE', __FILE__);
            define('ARTICLES_RS_PATH', plugin_dir_path(__FILE__));
            define('ARTICLES_RS_URL', plugin_dir_url(__FILE__));
            define('ARTICLES_RS_BASENAME', plugin_basename(__FILE__));
            define('ARTICLE_RS_INTERACTION_TABLE', "user_interaction");
            define('ARTICLE_RS_SEARCH_TERMS_TABLE', 'search_terms');
            define('ARTICLE_RS_RATING_SCALE_TABLE', 'rating_scale');
            define('ARTICLE_RS_UNREGISTERED_USER', 'unregistered_users');
            define('ARTICLES_RS_VERSION', '1.0');
        }

        public static function activate()
        {
            update_option('rewrite_rules', '');
        }

        public static function deactivate()
        {
            flush_rewrite_rules();
        }

        public static function uninstall()
        {
        }
    }
}

if (class_exists('Articles_rs')) {
    register_activation_hook(__FILE__, array('Articles_rs', 'activate'));
    register_deactivation_hook(__FILE__, array('Articles_rs', 'deactivate'));
    register_uninstall_hook(__FILE__, array('Articles_rs', 'uninstall'));
    $articles_rs = new Articles_rs();
}
