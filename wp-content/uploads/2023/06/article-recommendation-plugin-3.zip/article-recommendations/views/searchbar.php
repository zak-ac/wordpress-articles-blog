<?php

$cat = '';
$cat_array = [];

$user_id = "";
$user_ip = "";

if (is_user_logged_in()) {
    $user_id = get_current_user_id();
} else {
    $user_ip = $_SERVER['REMOTE_ADDR'];
}



if (isset($_COOKIE['articles_rs_categories_post'])) {
    $cat = $_COOKIE['articles_rs_categories_post'];
    $cat_array = explode(',', $cat);
} else {
    // get all categories
    $categories = get_categories(array(
        'orderby' => 'name',
        'order'   => 'ASC',
    ));
    if (empty($cat)) {
        foreach ($categories as $category) {
            if ($category->name != 'Uncategorized') {
                $cat_array[] = $category->term_id;
            }
        }
    }
}


$relation = [];

foreach ($cat_array as $key => $cat) {
    $relation[] = array(
        'taxonomy' => 'category',
        'field' => 'term_id',
        'terms' => $cat,
    );
}

$the_query = new WP_Query(array(
    'post_type' => 'post',
    'posts_per_page' => 12,
    'post_status' => 'publish',
    'category__in' => $cat_array,
));


$content = '';


if ($the_query->have_posts()) :

    $content .= "<div class='posts-container'>";
    while ($the_query->have_posts()) : $the_query->the_post();
        $content .= "<div class='post-item'>";
        $content .= "<a href='" . get_the_permalink() . "'>";
        $content .= get_the_title();
        $content .= "</a>";
        $content .= "<div>";
        $content .= "<p>" . get_the_excerpt() . "</p>";
        $content .= "</div>";
        $content .= "<div>";
        $content .= "<p>" . get_the_date() . "</p>";
        $content .= "</div>";
        $content .= "<div>";
        $content .= "<p>" . get_the_category_list(', ') . "</p>";
        $content .= "</div>";
        $content .= "</div>";
    endwhile;
    $content .= "</div>";
    wp_reset_postdata();
endif;

?>

<form action="/" method="get" autocomplete="off" id="arsSearch">
    <div class="search-container">
        <div class="input-wrapper">
            <input type="search" name="s" placeholder="Recherche..." value="<?php the_search_query(); ?>" class="ars-search" id="arsSearchInput" data-user-id="<?php echo $user_id;  ?>" data-user-ip="<?php echo $user_ip; ?>" />
        </div>
        <div class=" button-wrapper">
            <button class="ars-search-button" id="searchSubmit">Rechercher</button>
        </div>
    </div>
</form>
<!-- <div id="updateInterests">
    <p>Update interests</p>
</div> -->
<div class="articles-container"><?php echo $content; ?></div>