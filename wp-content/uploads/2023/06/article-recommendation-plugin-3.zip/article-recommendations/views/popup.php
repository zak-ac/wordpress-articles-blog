<?php


$first_visit = 'no';
if (isset($_COOKIE['first_visit'])) {
    $first_visit = $_COOKIE['first_visit'];
}

$cookies_accepted = 'no';
if (isset($_COOKIE['accept_terms'])) {
    $cookies_accepted = $_COOKIE['accept_terms'];
}

$categories = array();

$decoded_categories = [];
$fetched_categories = [];


$helpers = new DFR_Helpers();
$user_interaction_class = new DFR_User_interactions();

$response_categories = $helpers->get_categories_from_model();

if (isset($response_categories['body'])) {
    $decoded_categories = json_decode($response_categories['body']);
    $fetched_categories = $decoded_categories->list_categories;
}


$insert_categories = $helpers->add_categories_from_model($fetched_categories);

$user_interactions_array = $user_interaction_class->get_all_interactions();
$user_interactions = $helpers->parse_user_interactions($user_interactions_array);



if (is_user_logged_in()) {

    $user_id = get_current_user_id();

    $user_interactions = new DFR_User_interactions();
    $categories = $user_interactions->get_categories($user_id);
}

// Get all post categories
$categories = get_categories(array(
    'orderby' => 'name',
    'order'   => 'ASC'
));
?>

<div class="cat-popup-overlay <?php echo $first_visit == 'no' || empty($categories)  ? 'show-popup' : ''; ?>">
    <div class="cat-popup-inner">
        <div class="cat-popup-header">
            <p>Please select your interests</p>
        </div>
        <div class="cat-body">
            <div class="cat-container">
                <?php
                $categoriesArray = [];
                foreach ($categories as $category) {
                    if ($category->name != 'Uncategorized') {
                        $categoriesArray[] = $category->term_id;
                        $categoriesString = implode(',', $categoriesArray);
                ?>
                        <div class="cat-item" data-postid="<?php echo $category->term_id;  ?>"><?php echo $category->name; ?></div>
                <?php
                    }
                }
                ?>
                <input type="hidden" id="allCat" value="<?php echo esc_attr($categoriesString); ?>" />
            </div>
        </div>
        <div class="cat-footer">
            <button id="submitCat">Continue</button>
        </div>
    </div>
    <?php if ($cookies_accepted == 'no') { ?>
        <div class="ars-cookies-popup-overlay" id="arsCookiesPopupOverlay">

            <p>Like most websites, we use cookies to make our site work the way you expect it to, improve your experience on our site, analyze site usage, and assist in our marketing efforts. By choosing "Accept", you agree to the storing of all categories of cookies on your device. If you wish to reject some or all categories of cookies, please click
              <a href="#">"More Options"</a>  
            </p>
   
            <div class="ars-cookies-actions">
                <div class="ars-cookies-button-container">
                    <button id="acceptCookiesButton">Accept All Cookies</button>
                    <button id="denyCookiesButton">Reject All</button>
                </div>

            </div>
        </div>
    <?php } ?>
</div>